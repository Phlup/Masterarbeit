from project_lib.genotype_simulation import *
from project_lib.stat_functions import *

#usage: Read in genetic map, parental genotypes and reference allele to simulate genotypes of offspring w.r.t. params
#set in genotype_simulation()

if __name__ == '__main__':
    # read genetic map
    genmap = pd.read_csv("data/sim_data/B73_genmap.csv")
    # read parent genotypes
    parent_genos = pd.read_csv("data/sim_data/NAM_parent_genos.csv")
    # read reference allele
    ref_allele = pd.read_csv("data/sim_data/B73_alleles.csv")

    #get all founder names from parent genotypes
    founders = parent_genos["RIL"]

    #get all crosses (B73 x all others)
    founder_pairs = [(founders[0], non_b73) for non_b73 in founders[1:]]

    #get first cross (B73 x B97, population 1)
    cross = founder_pairs[0]

    #simulate genotype of B73xB97 cross + 5 selfing generations for 200 offspring
    whole_sim = genotype_simulation(genetic_map=genmap, parent_genos=parent_genos, ref_allele=ref_allele,
                                    founder_list=cross, offspring=200, selfing_genos=5)

    #save simulation
    whole_sim.to_csv("sim_output/geno_encoding/geno_" + cross[0] + "_" + cross[1] + ".csv")

    #generate additive encoding based on reference allele (B73 allele: -1, Het: 0, non-B73: 1)
    add_sim = additive_encoding(ref_allele, whole_sim)

    #save additive encoding
    add_sim.to_csv("sim_output/additive_encoding/geno_" + cross[0] + "_" + cross[1] + ".csv")
    print("finished simulating " + cross[0] + "x" + cross[1])

    #read in real population 1 genotype, add individual numbering and turn into additive encoding using reference allele
    pop_1_genos = pd.read_csv("data/NAM_genotype_data/pop_01_genos.csv")
    pop_1_genos = pop_1_genos[pop_1_genos.columns.intersection(genmap["Marker"])]
    pop_1_genos["individual"] = [i for i in range(len(pop_1_genos.index))]
    add_1 = additive_encoding(ref_allele, pop_1_genos)

    #create summary plot of real and simulated population 1
    summary_plot(real_additive = add_1, sim_additive = add_sim, founder_list = cross, out_path = "plots/summary_" + cross[0] + "_" + cross[1] + ".png")