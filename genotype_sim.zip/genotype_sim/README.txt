This is a short demonstration of using the population genetics tool msprime and
tskit to simulate entire genotypes of arbitrary pedigrees. Here, real data of
a cross between two recombinant inbred maize genotypes followed by 5 selfing
generations has been succesfully remodeled (1).

Redo the conda environment using the enivornment.yaml file:
conda env create -f environment.yaml

Then use the interpreter of that environment to run main.py or genotype_sim_demo.ipynb

Project structure:
data/ 
-contains material from (1, NAM_map_and_genos-121025) and (2, Buckler_etal_2009_Science_flowering_time_data-090807).
-cleaned genotype data for all 26 populations from (1) in NAM_genotype_data
-data necessary for genotype simulation (reference allele, genmap, NAM_parent_genos) in sim_data
plots/
-collects plots from genotype simulation
project_lib/
-contains .py files containing functions for genotype simulation and statistical evaluation of simulation
R_scripts/
-contains recomb_rates.R that shows how the genetic map from (1) was processed to get cM/Mb rates necessary for msprime
sim_output/
-collects simulation output files

The jupyter notebook genotype_sim_demo.ipynb demonstrates the genotype_simulation
function and data/models used by it.

main.py shows an example of simulating population 1 of NAM_genotype_data and using a summary plot to compare genotype distributions
simulation output is saved into sim_output/ and plot into plots/

(1): Genetic Design and Statistical Power of Nested Association Mapping in Maize,
Yu et al. 2008, Genetics, Volume 178, Issue 1. https://doi.org/10.1534/genetics.107.074245

(2): The genetic architecture of maize flowering time, Buckler et al. 2009, 
Science. 2009 Aug 7;325(5941):714-8. doi: 10.1126/science.1174276.