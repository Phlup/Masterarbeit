This is a short demonstration of using the population genetics tool msprime and
tskit to simulate entire genotypes of arbitrary pedigrees. Here, real data of
a cross between two recombinant inbred maize genotypes followed by 5 selfing
generations has been succesfully remodeled (1).
pedigree_functions.py contains helper functions to use the data model of tskit
to propagate known genotypes along an ancestral recombination graph.

Redo the conda environment using the enivornment.yaml file:
conda env create -f environment.yaml

The jupyter notebook genotype_sim_demo.ipynb demonstrates the genotype_simulation
function and data/models used by it.


(1): Genetic Design and Statistical Power of Nested Association Mapping in Maize,
Yu et al. 2008, Genetics, Volume 178, Issue 1. https://doi.org/10.1534/genetics.107.074245